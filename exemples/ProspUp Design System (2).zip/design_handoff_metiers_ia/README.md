# Handoff — Page Métiers IA (Piste F · Arbre + Détail)

## Aperçu

Refonte du **body** de la page **Métiers IA** (`/metiers-ia` ou équivalent) du back-office Prosp'Up v30+.
Objectif : remplacer la grille de cartes actuelle par une **arborescence visuelle** Catégorie → Métier, accompagnée d'un **panneau de détail** à droite pour le drill-in d'un métier.

![Aperçu de la cible](screenshots/hero.png)

> *L'aperçu ci-dessus est rendu à 1440×900 px scalé pour la capture. Ouvrir `preview.html` dans un navigateur à pleine largeur pour la fidélité native.*

---

## ⚠️ Périmètre — Important

**Ne PAS toucher** :
- La sidebar (`navigate`, `records`, `outils`, footer version)
- Le topbar (breadcrumb « ProspUp › Référentiels › Métiers IA », search ⌘K, bouton « Créer », avatar)
- Tout footer global éventuel

**À refaire intégralement** :
- Tout le **body** de la page Métiers IA, c'est-à-dire :
  - L'en-tête de page (eyebrow + titre serif italique + sous-titre + actions)
  - La toolbar (search large + segmented Arbre/Liste/Matrice)
  - La grille à 2 colonnes : **arbre courbe** à gauche + **panneau détail** à droite

---

## À propos des fichiers fournis

Les fichiers dans `reference/` sont des **prototypes HTML/React + Babel inline**. Ils servent de **référence visuelle et de spec exécutable**, pas de code de production.

La page cible doit être **réimplémentée dans la stack existante du projet** (Django + templates HTML, ou React, ou autre — selon la convention du codebase Prosp'Up v30/v32). Reprendre :
- Les tokens CSS de `colors_and_type.css` (déjà alignés sur `static/css/v30/tokens.css`)
- La structure et les mesures exactes décrites plus bas
- Le comportement décrit (sélection, hover, états)

## Fidélité

**High-fidelity (hifi)**. Tout est figé : couleurs, typographie, espacements, courbes SVG, transitions. Reproduire au pixel près.

---

## Stack visuelle

- **Polices** : `Inter` (UI), `Instrument Serif` (titres italiques, KPI), `JetBrains Mono` (compteurs, kbd, codes secteurs)
- **Couleurs** : variables OKLCH déclarées dans `reference/colors_and_type.css` (à mirrorer dans le projet si pas déjà fait — sinon importer les classes existantes)
- **Accent** : indigo `oklch(0.58 0.17 258)` (déjà dans le DS)
- **4 couleurs de famille** (catégories de métiers) :
  | Catégorie | Code | Couleur OKLCH |
  |---|---|---|
  | Ingénierie Logicielle | `logi` | `oklch(0.62 0.18 278)` (violet/indigo) |
  | Ingénierie Électronique | `elec` | `oklch(0.72 0.16 75)` (ambre) |
  | Ingénierie Système | `sys` | `oklch(0.66 0.12 175)` (teal) |
  | Life Science | `life` | `oklch(0.70 0.18 350)` (rose) |

---

## Données (modèle)

Voir `reference/_data.jsx` pour la source complète. Forme :

```ts
type Categorie = {
  k: 'logi' | 'elec' | 'sys' | 'life';
  label: string;
  color: string;   // OKLCH
};

type Secteur = {
  k: string;       // ex: 'auto', 'aero', 'pharm'
  label: string;
};

type Metier = {
  cat: Categorie['k'];
  name: string;
  desc: string;              // description longue (~140-180 caractères)
  short: string;             // résumé 1 ligne (~50 caractères)
  secteurs: Secteur['k'][];  // ['auto', 'aero', ...] ou ['all']
};
```

**26 métiers** répartis : 8 logi + 4 elec + 8 sys + 6 life. Données complètes dans `_data.jsx`.

**Champs additionnels par métier** à exposer dans l'API/le modèle si pas déjà présents :
- `vol_prospects` (int) — nombre de prospects tagués avec ce métier (sert au compteur du chip et aux KPIs du détail)
- `vol_entreprises` (int)
- `vol_besoins_open` (int)
- `keywords` (string[]) — mots-clés IA associés au métier (ex: pour "Logiciels embarqués" : `['embarqué','firmware','BSP','RTOS','C/C++','Linux embarqué','bare-metal','MCU','I²C/SPI','CAN']`)

---

## Structure du body

```
.rfn-page  (padding: 18px 22px 22px, flex column, gap 14px)
├── PageHdr                           ← en-tête de page
│   ├── eyebrow                       "PISTE F — ARBRE + DÉTAIL"  (à remplacer par éventuel breadcrumb sémantique)
│   ├── h1 (Instrument Serif italic)  "Métiers & tags IA."
│   ├── sub                           "L'arborescence courbe en lecture · le drill-in d'un métier à droite."
│   └── actions [Export, + Ajouter]
│
└── .v6-wrap (flex column, gap 12px, flex:1)
    ├── .v6-toolbar (flex row, gap 8)
    │   ├── search field              (flex:1, h:30, icon ⌕, kbd ⌘K)
    │   └── rfn-seg                   [Arbre · Liste · Matrice]   (segmented control)
    │
    └── .v6-grid (display:grid, grid-template-columns: 1fr 380px, gap 12, flex:1)
        ├── .v6-pane (TREE)
        └── .v6-pane (DETAIL)
```

L'en-tête (PageHdr) suit déjà le pattern v30 (`rfn-hdr`) : eyebrow uppercase + h1 serif italique + sub + actions à droite. Voir `reference/_system.jsx` → `PageHdr` pour la classe.

---

## Composant 1 — Panneau Arbre (gauche)

### Cadre

- `background: var(--surface)` (`#ffffff`)
- `border: 1px solid var(--border)` (`var(--ink-200)`)
- `border-radius: 12px` (`--r-card`)
- `overflow: hidden`
- Hauteur : `flex: 1` (remplit l'espace vertical disponible)

### Header du panneau (`.v6-tree-h`)

- Hauteur ~44px, padding `11px 14px`, border-bottom `1px solid var(--border)`
- Contenu :
  - Titre `« Arborescence métiers »` — Instrument Serif italic 17px, `var(--ink-900)`, `letter-spacing: -0.2px`
  - Compteur `« 4 familles · 26 métiers »` — JetBrains Mono 10.5px, `var(--ink-500)`
  - À droite : 2 boutons-icônes 22×22 (border 1px, radius 5px) :
    - ⊟ Tout replier (`title="Replier"`)
    - ⊕ Centrer (`title="Centrer"`)

### Canvas de l'arbre

Conteneur scrollable. Document interne en positions absolues, dimensions natives **800 × 612 px (min)**. La hauteur s'étend si nécessaire (calcul dynamique selon les catégories).

#### Géométrie (constantes)

```js
const CAT_X = 14;      // x du bord gauche des cartes catégorie
const CAT_W = 184;     // largeur cartes catégorie
const CAT_H = 50;      // hauteur cartes catégorie
const COL1_X = 230;    // x col 1 des chips métiers
const COL2_X = 522;    // x col 2 des chips métiers
const MET_W = 258;     // largeur chip métier
const MET_H = 30;      // hauteur chip métier
const MET_GAP = 6;     // gap vertical entre chips
const CAT_GAP = 22;    // gap vertical entre zones catégorie
const TOP = 16;        // marge top
```

#### Algorithme de placement

Pour chaque catégorie (dans l'ordre `logi`, `elec`, `sys`, `life`) :
1. Compter ses métiers (`items.length`).
2. Calculer `half = ceil(items.length / 2)` → nombre de lignes par colonne de chips.
3. `zoneH = half * (MET_H + MET_GAP) - MET_GAP`.
4. Placer la **carte catégorie** verticalement centrée dans sa zone (à `cy = yCursor + zoneH/2`).
5. Placer chaque **chip métier** :
   - col 0 si index < half, sinon col 1
   - row = index si col 0, sinon index - half
   - `x = (col == 0) ? COL1_X : COL2_X`
   - `y = startY + row * (MET_H + MET_GAP)`
6. `yCursor += zoneH + CAT_GAP`

Voir `reference/v6_arbre_detail.jsx` lignes 18-44 pour le code exact.

#### Carte catégorie (`.v6-cat`)

- Position : absolue (`left: CAT_X`, `top: cy - CAT_H/2`)
- Taille : `184 × 50 px`
- Style : background blanc, border 1px solid `var(--border)`, border-radius **10px**, padding `0 12px`, flex row align-center gap 9
- Contenu :
  - **Swatch** : carré 9×9 px, border-radius 3px, background = couleur de la famille
  - **Label** : Inter 12px / weight 600, `var(--ink-900)`, line-height 1.2
  - **Compteur** : JetBrains Mono 10.5px, `var(--ink-500)`, padding `2px 6px`, background `var(--ink-100)`, border-radius 4px
- **États** :
  - hover : `transform: translateY(-1px)`, `box-shadow: 0 4px 12px oklch(0 0 0 / .06)`
  - **`.on`** (catégorie parente du métier sélectionné) : `border-color: transparent`, `box-shadow: 0 0 0 2px <couleur-famille>` (double-bordure pleine)
- Transitions : 0.15s ease

#### Chip métier (`.v6-met`)

- Position : absolue (`left: x`, `top: y`, `width: 258`)
- Taille : `258 × 30 px`
- Style : background blanc, border 1px solid `var(--border)`, border-radius **7px**, padding `0 9px 0 11px`, flex row align-center gap 7
- Contenu :
  - **Dot** : cercle 6×6 px, background = couleur de la famille
  - **Nom** : Inter 11.5px / weight 500, `var(--ink-800)`, `text-overflow: ellipsis`, `white-space: nowrap` (le full name est dans `title=` pour le tooltip natif)
  - **Volume** : JetBrains Mono 9.5px, `var(--ink-400)` (nombre de prospects tagués)
- **États** :
  - hover : background `var(--ink-100)`, `transform: translateX(2px)`
  - **`.on`** (métier sélectionné) :
    - background `var(--accent-soft)` (indigo très pâle)
    - border `var(--accent)`
    - `box-shadow: 0 2px 8px oklch(0.58 0.17 258 / .14)`
    - nom : couleur `var(--accent)`, weight **600**
    - volume : couleur `var(--accent)`
- Transitions : 0.12s background/border, 0.15s transform

#### Connecteurs SVG

SVG en `position: absolute; inset: 0; pointer-events: none;` couvrant tout le canvas, `viewBox="0 0 800 totalH"`.

**Une courbe par chip métier** :
- De : (`CAT_X + CAT_W`, `cy_catégorie`) — bord droit de la carte catégorie, à sa hauteur centre
- Vers : (`chip.x`, `chip.y + MET_H/2`) — bord gauche du chip, à sa hauteur centre
- Type : **cubic bezier** avec contrôle horizontal :
  ```
  const dx = (x2 - x1) * 0.55;
  d = `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
  ```
- **Style** par défaut :
  - `stroke: <couleur-famille>`
  - `stroke-width: 1.25`
  - `fill: none`
  - `opacity: 0.32`
- **Style sur le chemin sélectionné** (courbe vers le métier `.on`) :
  - `stroke-width: 2`
  - `opacity: 0.95`

**Plus** : un petit cercle d'ancrage `r=3.5` au point de départ de chaque catégorie (`cx: CAT_X + CAT_W, cy: catégorie.cy`), rempli de la couleur de la famille.

---

## Composant 2 — Panneau Détail (droite)

### Cadre

Même `.v6-pane` (surface blanche, border, radius 12). Largeur **fixe 380 px**.

Layout interne : `display: flex; flex-direction: column; min-height: 0;` → header / body scrollable / footer sticky.

### Header (`.v6-det-h`)

- Padding `16px 18px 14px`, border-bottom 1px
- **Crumb** (au-dessus du titre) :
  - Layout flex row align-center gap 6, margin-bottom 10
  - Font : JetBrains Mono 10px, uppercase, letter-spacing 0.04em, `var(--ink-500)`
  - Format : `[swatch 7×7] <nom catégorie> [›] Métier`
  - Le `›` est un span séparé `color: var(--ink-300)`
- **Titre** (`h2`) :
  - Instrument Serif **italic**, weight 400, **22px**, line-height 1.15
  - `letter-spacing: -0.2px`, color `var(--ink-900)`
  - Contenu : nom complet du métier (peut wrapper sur 2-3 lignes)

### Body scrollable (`.v6-det-body`)

`padding: 16px 18px; gap: 18px; overflow: auto; flex: 1`. Une succession de sections, chacune avec un label sec + contenu.

**Label de section** (`.v6-sec-label`) :
- font 10px / weight 600 / letter-spacing 0.08em / uppercase
- color `var(--ink-500)`
- margin-bottom 8px
- Si présent, un compteur Mono à droite (`margin-left: auto`) : weight 500, color `var(--ink-400)`, NON-uppercase, font-family Mono

#### Section 1 — Définition IA

- Label : `« Définition IA »`
- Contenu : `<div class="v6-desc">` — Inter 12.5px, `var(--ink-800)`, line-height 1.55, `text-wrap: pretty`
- Texte : `metier.desc`

#### Section 2 — Usage

- Label : `« Usage »`
- 3 cartes KPI en grid 3 colonnes égales, gap 8 :
  - background `var(--ink-100)`, border-radius 8px (`--r-md`), padding `10px 12px`, position relative
  - Label haut : 9.5px / weight 500 / letter-spacing 0.06em / uppercase / `var(--ink-500)`
  - Valeur : **Instrument Serif 22px**, `var(--ink-900)`, line-height 1, margin-top 5
- KPIs :
  - **Prospects** : `metier.vol_prospects` — un trend optionnel en haut droite (« ↑ 12 », Mono 9.5px, `var(--success)`)
  - **Entreprises** : `metier.vol_entreprises`
  - **Besoins** : `metier.vol_besoins_open`

#### Section 3 — Secteurs rattachés

- Label avec compteur (nombre de secteurs)
- Pills horizontales en flex-wrap gap 5 :
  - font 11px, padding `3px 9px`, border-radius pill (999px)
  - border 1px solid `var(--border)`, background blanc
  - Dot 6×6 px à gauche, color = couleur de la famille
  - Label du secteur en `var(--ink-700)`
- Dernière pill « ＋ Ajouter » : border-style **dashed**, color `var(--ink-500)`

#### Section 4 — Mots-clés IA

- Label avec compteur (nb de keywords)
- Mêmes pills mais en **JetBrains Mono 10.5px**, padding `3px 7px`, sans dot
- Source : `metier.keywords`

### Footer (`.v6-det-foot`)

- `border-top: 1px solid var(--border)`, padding `10px 14px`
- `display: flex; gap: 6px; background: var(--surface)`
- Pas explicitement sticky dans la cible — la pane elle-même gère la mise en page. Le body est scrollable, le footer reste visible en bas.
- Boutons (style `rfn-btn-ghost` : h 24px, border, radius 6, font 11.5px) :
  - `✎ Éditer`
  - `⎘ Dupliquer`
  - **Spacer** (`flex: 1`)
  - `⌫ Supprimer` — couleur `var(--danger)`

---

## Toolbar (au-dessus de la grille)

Hauteur ~30px, flex row gap 8.

### Search

- Flex 1, min-width 240, h 30
- Background `var(--surface)`, border 1px solid `var(--border)`, radius 8px
- Padding `0 10px`, gap 8
- Icône ⌕ + placeholder « *Rechercher un métier, une techno, un secteur…* » (Inter 12px, `var(--ink-500)`)
- À droite, un raccourci clavier :
  - Span Mono 9.5px, h 14px, padding `0 4px`
  - background `var(--surface-2)`, border 1px, radius 3px
  - Texte : `⌘K`

### Segmented control (`rfn-seg`)

- Inline-flex, padding 2, background `var(--surface-2)`, border 1px, radius 6px (`--r-sm`)
- 3 onglets : `« Arbre » (on), « Liste », « Matrice »`
- Chaque onglet : padding `3px 9px`, font 11px / weight 500, color `var(--ink-600)`, radius 4
- Actif : background `var(--surface)` (blanc), color `var(--ink-900)`, `box-shadow: 0 1px 2px rgba(0,0,0,.06)`
- Le segmented existe déjà dans `_system.jsx` sous la classe `.rfn-seg` — réutiliser

---

## Interactions & comportements

### Sélection d'un métier

- Clic sur un chip métier → cet item devient `.on`
- En cascade dans l'UI :
  1. Le chip est passé en accent (background bleu pâle, border accent)
  2. Sa courbe SVG vers la catégorie passe en `stroke-width: 2` + `opacity: 0.95`
  3. Sa carte catégorie parente passe en `.on` (double-bordure couleur famille)
  4. Le panneau détail à droite affiche les infos du métier

### Hover

- Catégorie : translation Y de -1px + ombre douce
- Chip métier : background `var(--ink-100)` + translation X de +2px
- Bouton ghost : background `var(--ink-100)` (style par défaut)

### Toolbar Arbre / Liste / Matrice

- Toggle de vue (3 modes). Dans le scope F, seul « Arbre » est implémenté visuellement.
- Si « Liste » et « Matrice » ne sont pas livrés dans ce ticket : laisser cliquables mais inactifs (`pointer-events: none` ou navigation vers route sans contenu OK).
- Persist la sélection en query string si possible (`?view=tree|list|matrix`).

### Replier / Centrer (boutons header tree)

- Replier (⊟) : optionnel, à câbler si le besoin se présente (collapse les chips, ne garde que les 4 catégories). Dans le scope F initial, on peut **omettre** ces actions ou les laisser inactives. À discuter.
- Centrer (⊕) : remet le scroll du canvas à `(0, 0)` ou centre sur le métier sélectionné. Bonus.

### Empty state

Si aucun métier sélectionné par défaut au premier chargement :
- Sélectionner le premier métier de la liste (ex: `Logiciel applicatif`) pour ne jamais avoir le panneau détail vide.

### Responsive

Le design vise **viewport ≥ 1440 px**. Pour les écrans plus petits, deux stratégies acceptables (à confirmer avec le PO) :
1. **Scroll horizontal** du panneau arbre (gardé largeur native 800px interne, scroll dans `.v6-canvas`)
2. **Stacking** vertical : panneau détail passe en dessous (breakpoint à définir, ex: ≤1200px)

Le prototype implémente la stratégie 1 (scrollable, sans repli).

---

## Design tokens utilisés (résumé)

### Couleurs

| Token | Valeur OKLCH | Usage |
|---|---|---|
| `--ink-0` à `--ink-1000` | scale froide hue 258 | textes, borders, surfaces |
| `--surface` | `#ffffff` | fond des cartes / panneaux |
| `--surface-2` | `--ink-100` | fond search, segmented inactif |
| `--border` | `--ink-200` | bordures |
| `--accent` | `oklch(0.58 0.17 258)` | sélection, boutons primaires |
| `--accent-soft` | `oklch(0.94 0.04 258)` | background de sélection |
| `--accent-fg` | `oklch(0.99 0.01 258)` | texte sur accent |
| `--success` | `oklch(0.62 0.14 155)` | trends positifs |
| `--danger` | `oklch(0.58 0.18 25)` | bouton supprimer |
| **`cat-logi`** | `oklch(0.62 0.18 278)` | famille Logicielle |
| **`cat-elec`** | `oklch(0.72 0.16 75)` | famille Électronique |
| **`cat-sys`** | `oklch(0.66 0.12 175)` | famille Système |
| **`cat-life`** | `oklch(0.70 0.18 350)` | famille Life Science |

### Radius

- `--r-sm: 6px` — segmented, chips toolbar
- `--r-md: 8px` — search, KPI cards
- `--r-card: 12px` — panneaux principaux
- chip métier : **7px** (custom, plus serré)
- carte catégorie : **10px** (custom)
- pill (sectors) : 999px

### Spacing

Utiliser la scale `--s-1` à `--s-20` (4, 8, 12, 16, 20, 24, 32, 40, 56, 80). Toutes les valeurs spécifiques dans ce doc sont en pixels en dur — à mapper vers les tokens si possible.

### Typographie

| Élément | Famille | Taille | Weight | Style |
|---|---|---|---|---|
| h1 (titre page) | Instrument Serif | 26px | 400 | **italic** |
| h2 (titre détail) | Instrument Serif | 22px | 400 | **italic** |
| Titre tree header | Instrument Serif | 17px | 400 | italic |
| Eyebrow | Inter | 10.5px | 500 | uppercase, letter-spacing 0.08em |
| Section label détail | Inter | 10px | 600 | uppercase, letter-spacing 0.08em |
| Description IA | Inter | 12.5px | 400 | line-height 1.55, text-wrap pretty |
| Carte catégorie label | Inter | 12px | 600 | — |
| Chip métier label | Inter | 11.5px | 500 (600 si .on) | — |
| KPI value | Instrument Serif | 22px | 400 | — |
| KPI label | Inter | 9.5px | 500 | uppercase, letter-spacing 0.06em |
| Compteurs (mono) | JetBrains Mono | 9.5-10.5px | 500 | tabular-nums |
| Pills mots-clés | JetBrains Mono | 10.5px | 400 | — |

---

## Comportements responsifs des transitions

- Hover catégorie : `transition: transform .15s, box-shadow .15s, border-color .15s`
- Hover chip métier : `transition: background .12s, border-color .12s, transform .15s`
- Search/segmented : pas de transition particulière
- SVG strokes : pas de transition (changement immédiat à la sélection)

---

## Fichiers fournis

- **`preview.html`** — Aperçu **runnable** de la cible. Ouvrir dans un navigateur à pleine largeur (1440+) pour voir le rendu fidèle.
- **`screenshots/hero.png`** — Capture de l'aperçu (scalé).
- **`reference/v6_arbre_detail.jsx`** — Code React JSX **complet et commenté** du body. C'est la source de vérité.
- **`reference/_data.jsx`** — Données complètes (CATS, SECTEURS, 26 METIERS).
- **`reference/_system.jsx`** — Primitives Shell / Side / Top / PageHdr / StatusPill / KPI / Avatar et la CSS de base (`RefonteStyles`). **À considérer en lecture seule** : ces composants représentent la sidebar / topbar existante.
- **`reference/colors_and_type.css`** — Tokens du Design System v30 (mirror de `static/css/v30/tokens.css`).

---

## Checklist d'implémentation

- [ ] Ne pas modifier la sidebar, le topbar, ni un footer global
- [ ] Conserver la classe / rôle de `PageHdr` du DS
- [ ] Implémenter la toolbar (search + segmented Arbre/Liste/Matrice)
- [ ] Implémenter le panneau arbre avec :
  - [ ] Header avec titre serif italic + compteur Mono + boutons icônes
  - [ ] Canvas interne 800 × ≥612 px scrollable
  - [ ] 4 cartes catégorie positionnées en absolu selon l'algorithme
  - [ ] 26 chips métier en 2 colonnes par catégorie
  - [ ] SVG full-cover avec une cubic-bezier par chip + cercles d'ancrage
  - [ ] États `.on` pour catégorie + chip + courbe lors de la sélection
- [ ] Implémenter le panneau détail (380px) :
  - [ ] Header avec crumb mono uppercase + h2 serif italic
  - [ ] Section Définition IA
  - [ ] Section Usage (3 KPIs Instrument Serif)
  - [ ] Section Secteurs (pills avec dot couleur famille + « + Ajouter » dashed)
  - [ ] Section Mots-clés IA (pills mono)
  - [ ] Footer actions (Éditer / Dupliquer / Supprimer en danger)
- [ ] Sélection : un clic met à jour les 4 zones (chip / courbe / catégorie parent / panneau détail)
- [ ] Vérifier la fidélité au screenshot `hero.png` ouvert à 1440px

---

## Questions ouvertes (à arbitrer avec le PO)

1. **Source des compteurs** (`vol_prospects`, `vol_entreprises`, `vol_besoins_open`) — existent-ils déjà en base, ou à calculer via aggregations ?
2. **Mots-clés IA** — gérés où ? Champ texte libre côté admin métier ?
3. **Modes Liste / Matrice** dans la toolbar : on les livre maintenant (variantes B et C disponibles dans le projet de design), ou plus tard ?
4. **Édition inline** d'un métier : modale, drawer ou page dédiée ?
5. **Action « ＋ Ajouter »** (header de page) : ouvre un drawer dans le panneau détail à droite ? Ou une modale ?
