/* global React, Shell, PageHdr, CATS, METIERS, secByK, catByK */
// Piste F — Arbre horizontal + panneau détail
// Mélange B + D : à gauche, l'arbre courbe en lecture (catégorie → métier
// via cubic-bezier), à droite, le panneau de drill-in d'un métier.
// La feuille sélectionnée fait remonter son chemin (chip + connecteur + cat
// en accent). Pensé comme la page Métiers définitive.

function MetiersV6() {
  // Géométrie de l'arbre — colonne gauche
  const W = 800, H = 612;
  const CAT_X = 14, CAT_W = 184, CAT_H = 50;
  const COL1_X = 230, COL2_X = 522;
  const MET_W = 258, MET_H = 30, MET_GAP = 6;
  const CAT_GAP = 22;
  const TOP = 16;

  // Sélection démo
  const SELECTED_NAME = 'Logiciels embarqués / Systèmes embarqués / IoT';

  // Placement vertical : zones par catégorie
  const placed = [];
  let yCursor = TOP;
  CATS.forEach(c => {
    const items = METIERS.filter(m => m.cat === c.k);
    const half = Math.ceil(items.length / 2);
    const zoneH = half * (MET_H + MET_GAP) - MET_GAP;
    const cy = yCursor + zoneH / 2;
    placed.push({ ...c, items, half, zoneH, startY: yCursor, cy });
    yCursor += zoneH + CAT_GAP;
  });
  const totalH = Math.max(yCursor - CAT_GAP + TOP, H);

  // Chips métier
  const chips = placed.flatMap(c =>
    c.items.map((m, i) => {
      const col = i < c.half ? 0 : 1;
      const row = i < c.half ? i : i - c.half;
      const x = col === 0 ? COL1_X : COL2_X;
      const y = c.startY + row * (MET_H + MET_GAP);
      return { ...m, x, y, col, catY: c.cy, catColor: c.color, catLabel: c.label, on: m.name === SELECTED_NAME };
    })
  );

  const selected = chips.find(m => m.on) || chips[0];
  const selectedCat = placed.find(c => c.k === selected.cat);

  // Courbe SVG
  const curve = (x1, y1, x2, y2) => {
    const dx = (x2 - x1) * 0.55;
    return `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
  };

  const css = `
    .v6-wrap { display:flex; flex-direction:column; gap:12px; height:100%; min-height:0; }
    .v6-toolbar { display:flex; align-items:center; gap:8px; }
    .v6-toolbar .search { flex:1; min-width:240px; height:30px; background:var(--surface); border:1px solid var(--border); border-radius:var(--r-md); padding:0 10px; display:flex; align-items:center; gap:8px; font-size:12px; color:var(--ink-500); }
    .v6-toolbar .kbd { margin-left:auto; font-family:var(--font-mono); font-size:9.5px; background:var(--surface-2); border:1px solid var(--border); border-radius:3px; padding:0 4px; height:14px; display:inline-flex; align-items:center; }

    .v6-grid { display:grid; grid-template-columns: 1fr 380px; gap:12px; flex:1; min-height:0; }
    .v6-pane { background:var(--surface); border:1px solid var(--border); border-radius:var(--r-card); overflow:hidden; display:flex; flex-direction:column; min-height:0; }

    /* TREE PANE */
    .v6-tree-h { display:flex; align-items:center; padding:11px 14px; border-bottom:1px solid var(--border); gap:10px; }
    .v6-tree-h .ttl { font-family:var(--font-serif); font-style:italic; font-size:17px; color:var(--ink-900); letter-spacing:-.2px; }
    .v6-tree-h .ct { font-family:var(--font-mono); font-size:10.5px; color:var(--ink-500); }
    .v6-tree-h .acts { margin-left:auto; display:flex; gap:6px; }
    .v6-tree-h .ico-btn { width:22px; height:22px; border-radius:5px; border:1px solid var(--border); background:var(--surface); display:inline-flex; align-items:center; justify-content:center; font-size:11px; color:var(--ink-600); cursor:pointer; }

    .v6-canvas { position:relative; flex:1; min-height:0; overflow:auto; }
    .v6-inner { position:relative; width:${W}px; height:${totalH}px; }
    .v6-svg { position:absolute; inset:0; pointer-events:none; }

    .v6-cat {
      position:absolute; width:${CAT_W}px; height:${CAT_H}px;
      display:flex; align-items:center; gap:9px; padding:0 12px;
      background: var(--surface); border:1px solid var(--border);
      border-radius: 10px; cursor:pointer;
      transition: transform .15s, box-shadow .15s, border-color .15s;
    }
    .v6-cat:hover { transform: translateY(-1px); box-shadow: 0 4px 12px oklch(0 0 0 / .06); }
    .v6-cat.on { border-color: transparent; box-shadow: 0 0 0 2px var(--cat-color); }
    .v6-cat .swatch { width:9px; height:9px; border-radius:3px; flex:0 0 auto; }
    .v6-cat .nm { font-size:12px; font-weight:600; color:var(--ink-900); flex:1; line-height:1.2; }
    .v6-cat .ct { font-family:var(--font-mono); font-size:10.5px; color:var(--ink-500); padding:2px 6px; background:var(--ink-100); border-radius:4px; font-weight:500; }

    .v6-met {
      position:absolute; height:${MET_H}px;
      display:flex; align-items:center; gap:7px; padding:0 9px 0 11px;
      background: var(--surface); border:1px solid var(--border);
      border-radius: 7px; cursor:pointer;
      transition: background .12s, border-color .12s, transform .15s;
    }
    .v6-met:hover { background:var(--ink-100); transform: translateX(2px); }
    .v6-met .dot { width:6px; height:6px; border-radius:50%; flex:0 0 auto; }
    .v6-met .nm { font-size:11.5px; font-weight:500; color:var(--ink-800); flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .v6-met .vol { font-family:var(--font-mono); font-size:9.5px; color:var(--ink-400); }
    .v6-met.on {
      background: var(--accent-soft); border-color: var(--accent);
      box-shadow: 0 2px 8px oklch(0.58 0.17 258 / .14);
    }
    .v6-met.on .nm { color: var(--accent); font-weight:600; }
    .v6-met.on .vol { color: var(--accent); }

    /* DETAIL PANE */
    .v6-det { display:flex; flex-direction:column; flex:1; min-height:0; }
    .v6-det-h { padding:16px 18px 14px; border-bottom:1px solid var(--border); }
    .v6-det-h .crumb { font-family:var(--font-mono); font-size:10px; color:var(--ink-500); display:flex; align-items:center; gap:6px; margin-bottom:10px; text-transform:uppercase; letter-spacing:.04em; }
    .v6-det-h .crumb .swatch { width:7px; height:7px; border-radius:2px; }
    .v6-det-h h2 { font-family:var(--font-serif); font-style:italic; font-weight:400; font-size:22px; line-height:1.15; color:var(--ink-900); letter-spacing:-.2px; }

    .v6-det-body { padding:16px 18px; display:flex; flex-direction:column; gap:18px; overflow:auto; flex:1; min-height:0; }
    .v6-sec-label { font-size:10px; font-weight:600; letter-spacing:.08em; text-transform:uppercase; color:var(--ink-500); margin-bottom:8px; display:flex; align-items:center; gap:6px; }
    .v6-sec-label .ct { font-family:var(--font-mono); font-weight:500; color:var(--ink-400); letter-spacing:0; text-transform:none; margin-left:auto; }
    .v6-desc { font-size:12.5px; color:var(--ink-800); line-height:1.55; text-wrap:pretty; }

    .v6-stats { display:grid; grid-template-columns: repeat(3, 1fr); gap:8px; }
    .v6-stat { background:var(--ink-100); border-radius:var(--r-md); padding:10px 12px; position:relative; }
    .v6-stat .l { font-size:9.5px; letter-spacing:.06em; text-transform:uppercase; color:var(--ink-500); font-weight:500; }
    .v6-stat .v { font-family:var(--font-serif); font-size:22px; color:var(--ink-900); line-height:1; margin-top:5px; }
    .v6-stat .tr { position:absolute; top:10px; right:12px; font-family:var(--font-mono); font-size:9.5px; color:var(--success); font-weight:500; }

    .v6-secs { display:flex; flex-wrap:wrap; gap:5px; }
    .v6-secs .s { font-size:11px; color:var(--ink-700); padding:3px 9px; border-radius:var(--r-pill); border:1px solid var(--border); background:var(--surface); display:inline-flex; align-items:center; gap:6px; }
    .v6-secs .s .d { display:inline-block; width:6px; height:6px; border-radius:50%; }
    .v6-secs .s.kw { font-family:var(--font-mono); font-size:10.5px; color:var(--ink-700); padding:3px 7px; }

    .v6-det-foot { border-top:1px solid var(--border); padding:10px 14px; display:flex; gap:6px; background:var(--surface); }
    .v6-det-foot .grow { flex:1; }
  `;

  return (
    <Shell active="metiers" crumb={[{t:'Référentiels'},{t:'Métiers IA', last:true}]}>
      <style>{css}</style>
      <div className="rfn-page">
        <PageHdr
          eyebrow="Piste F — Arbre + détail"
          title={<>Métiers <i>&amp; tags IA.</i></>}
          sub="L'arborescence courbe en lecture · le drill-in d'un métier à droite."
          actions={
            <>
              <button className="rfn-btn-ghost">↓ Export</button>
              <button className="rfn-btn">＋ Ajouter</button>
            </>
          }
        />

        <div className="v6-wrap">
          <div className="v6-toolbar">
            <div className="search">⌕ Rechercher un métier, une techno, un secteur…<span className="kbd">⌘K</span></div>
            <div className="rfn-seg">
              <span className="on">Arbre</span>
              <span>Liste</span>
              <span>Matrice</span>
            </div>
          </div>

          <div className="v6-grid">
            {/* TREE */}
            <div className="v6-pane">
              <div className="v6-tree-h">
                <span className="ttl">Arborescence métiers</span>
                <span className="ct">4 familles · 26 métiers</span>
                <span className="acts">
                  <span className="ico-btn" title="Replier">⊟</span>
                  <span className="ico-btn" title="Centrer">⊕</span>
                </span>
              </div>

              <div className="v6-canvas">
                <div className="v6-inner">

                  {/* Connecteurs SVG */}
                  <svg className="v6-svg" viewBox={`0 0 ${W} ${totalH}`} preserveAspectRatio="none">
                    {chips.map((m, i) => (
                      <path key={i}
                        d={curve(CAT_X + CAT_W, m.catY, m.x, m.y + MET_H/2)}
                        stroke={m.catColor}
                        strokeWidth={m.on ? 2 : 1.25}
                        fill="none"
                        opacity={m.on ? 0.95 : 0.32}/>
                    ))}
                    {placed.map(c => (
                      <circle key={'rd-'+c.k} cx={CAT_X + CAT_W} cy={c.cy} r="3.5" fill={c.color}/>
                    ))}
                  </svg>

                  {/* Catégories */}
                  {placed.map(c => {
                    const onPath = c.k === selected.cat;
                    return (
                      <div key={c.k}
                        className={'v6-cat' + (onPath ? ' on' : '')}
                        style={{left: CAT_X, top: c.cy - CAT_H/2, ['--cat-color']: c.color}}>
                        <span className="swatch" style={{background:c.color}}/>
                        <span className="nm">{c.label}</span>
                        <span className="ct">{c.items.length}</span>
                      </div>
                    );
                  })}

                  {/* Métiers */}
                  {chips.map((m, i) => (
                    <div key={i}
                      className={'v6-met' + (m.on ? ' on' : '')}
                      style={{left: m.x, top: m.y, width: MET_W}}
                      title={m.name}>
                      <span className="dot" style={{background:m.catColor}}/>
                      <span className="nm">{m.name}</span>
                      <span className="vol">{[214,187,162,143,121,88,76,41][placed[0].items.indexOf(m)] || ''}</span>
                    </div>
                  ))}

                </div>
              </div>
            </div>

            {/* DETAIL */}
            <div className="v6-pane">
              <div className="v6-det">
                <div className="v6-det-h">
                  <div className="crumb">
                    <span className="swatch" style={{background:selectedCat.color}}/>
                    {selectedCat.label}<span style={{color:'var(--ink-300)'}}>›</span>Métier
                  </div>
                  <h2>{selected.name}</h2>
                </div>

                <div className="v6-det-body">
                  <div>
                    <div className="v6-sec-label">Définition IA</div>
                    <div className="v6-desc">{selected.desc}</div>
                  </div>

                  <div>
                    <div className="v6-sec-label">Usage</div>
                    <div className="v6-stats">
                      <div className="v6-stat"><div className="l">Prospects</div><div className="v">162</div><div className="tr">↑ 12</div></div>
                      <div className="v6-stat"><div className="l">Entreprises</div><div className="v">34</div></div>
                      <div className="v6-stat"><div className="l">Besoins</div><div className="v">7</div></div>
                    </div>
                  </div>

                  <div>
                    <div className="v6-sec-label">Secteurs rattachés<span className="ct">{selected.secteurs.length}</span></div>
                    <div className="v6-secs">
                      {selected.secteurs.map(sk => (
                        <span key={sk} className="s"><span className="d" style={{background:selectedCat.color}}/>{secByK[sk].label}</span>
                      ))}
                      <span className="s" style={{borderStyle:'dashed', color:'var(--ink-500)'}}>＋ Ajouter</span>
                    </div>
                  </div>

                  <div>
                    <div className="v6-sec-label">Mots-clés IA<span className="ct">10</span></div>
                    <div className="v6-secs">
                      {['embarqué','firmware','BSP','RTOS','C/C++','Linux embarqué','bare-metal','MCU','I²C/SPI','CAN'].map(t => (
                        <span key={t} className="s kw">{t}</span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="v6-det-foot">
                  <button className="rfn-btn-ghost">✎ Éditer</button>
                  <button className="rfn-btn-ghost">⎘ Dupliquer</button>
                  <div className="grow"/>
                  <button className="rfn-btn-ghost" style={{color:'var(--danger)'}}>⌫ Supprimer</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}

Object.assign(window, { MetiersV6 });
