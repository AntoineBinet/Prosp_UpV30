/* global React */
// ProspUp v30 — Refonte cohérente
// _system.jsx : tokens, primitives partagées, RefonteStyles (CSS unique).
// Boldness ~30 : on garde la DA actuelle, on tend la hiérarchie et la cohérence.

// Inject the CSS once at the canvas level.
function RefonteStyles() {
  const css = `
    /* ─── Tokens locaux (mirror tokens.css) ───────────────────────── */
    .rfn-root {
      --ink-0:    oklch(0.995 0.002 258);
      --ink-50:   oklch(0.985 0.003 258);
      --ink-100:  oklch(0.965 0.004 258);
      --ink-150:  oklch(0.945 0.005 258);
      --ink-200:  oklch(0.918 0.006 258);
      --ink-300:  oklch(0.870 0.008 258);
      --ink-400:  oklch(0.740 0.010 258);
      --ink-500:  oklch(0.600 0.012 258);
      --ink-600:  oklch(0.510 0.014 258);
      --ink-700:  oklch(0.395 0.015 258);
      --ink-800:  oklch(0.265 0.015 258);
      --ink-900:  oklch(0.175 0.014 258);

      --accent:        oklch(0.58 0.17 258);
      --accent-hover:  oklch(0.52 0.18 258);
      --accent-soft:   oklch(0.94 0.04 258);

      --success:       oklch(0.62 0.14 155);
      --warn:          oklch(0.74 0.15 75);
      --danger:        oklch(0.58 0.18 25);
      --info:          oklch(0.65 0.13 220);

      --st-idle:       oklch(0.44 0.05 250);
      --st-prosp:      oklch(0.40 0.15 195);
      --st-called:     oklch(0.40 0.14 165);
      --st-voicemail:  oklch(0.43 0.12 270);
      --st-callback:   oklch(0.44 0.16 55);
      --st-rdv:        oklch(0.40 0.16 290);
      --st-cold:       oklch(0.46 0.10 20);

      --bg:            var(--ink-100);
      --surface:       #ffffff;
      --surface-2:     var(--ink-100);
      --border:        var(--ink-200);
      --border-strong: var(--ink-300);

      --r-sm: 6px;
      --r-md: 8px;
      --r-lg: 10px;
      --r-card: 12px;
      --r-xl: 14px;
      --r-pill: 999px;

      --font-sans:  'Inter', ui-sans-serif, system-ui, sans-serif;
      --font-serif: 'Instrument Serif', Georgia, serif;
      --font-mono:  'JetBrains Mono', ui-monospace, monospace;

      background: var(--bg);
      color: var(--ink-900);
      font-family: var(--font-sans);
      font-size: 12.5px;
      font-feature-settings: "cv11", "ss01", "ss03";
      -webkit-font-smoothing: antialiased;
    }
    .rfn-root, .rfn-root *, .rfn-root *::before, .rfn-root *::after { box-sizing: border-box; }

    /* ─── Page shell ──────────────────────────────────────────────── */
    .rfn-shell { width:100%; height:100%; display:flex; overflow:hidden; }

    /* Sidebar */
    .rfn-side { width:188px; background:var(--surface); border-right:1px solid var(--border); padding:10px 8px; flex:0 0 auto; display:flex; flex-direction:column; font-size:11.5px; }
    .rfn-side .brand { display:flex; align-items:center; gap:8px; padding:4px 6px 12px; }
    .rfn-side .brand .mk { width:20px; height:20px; border-radius:5px; background:var(--ink-900); color:#fff; font-family:var(--font-serif); font-style:italic; font-size:13px; display:inline-flex; align-items:center; justify-content:center; }
    .rfn-side .brand .nm { font-weight:600; font-size:12px; letter-spacing:-.01em; }
    .rfn-side h6 { font-size:9.5px; font-weight:600; letter-spacing:.08em; text-transform:uppercase; color:var(--ink-500); padding:6px 6px 3px; margin:0; }
    .rfn-side .nav { display:flex; flex-direction:column; gap:1px; }
    .rfn-side a { display:flex; align-items:center; gap:8px; padding:5px 7px; border-radius:5px; color:var(--ink-700); font-weight:500; cursor:pointer; line-height:1.2; }
    .rfn-side a:hover { background:var(--surface-2); }
    .rfn-side a.on { background:var(--accent-soft); color:var(--accent); font-weight:600; }
    .rfn-side .ic { width:13px; height:13px; background:var(--ink-400); border-radius:3px; flex:0 0 auto; }
    .rfn-side a.on .ic { background:var(--accent); }
    .rfn-side .ct { margin-left:auto; font-family:var(--font-mono); font-size:9.5px; color:var(--ink-500); font-weight:500; }
    .rfn-side .foot { margin-top:auto; padding:6px; font-family:var(--font-mono); font-size:9.5px; color:var(--ink-500); display:flex; gap:8px; align-items:center; }

    /* Topbar */
    .rfn-top { height:42px; background:var(--surface); border-bottom:1px solid var(--border); display:flex; align-items:center; padding:0 14px; gap:10px; flex:0 0 auto; }
    .rfn-crumb { font-size:11.5px; color:var(--ink-600); display:flex; align-items:center; gap:5px; }
    .rfn-crumb b { color:var(--ink-900); font-weight:500; }
    .rfn-crumb .sep { color:var(--ink-400); }
    .rfn-search { flex:1; max-width:240px; height:24px; background:var(--surface-2); border:1px solid var(--border); border-radius:var(--r-sm); padding:0 9px; display:flex; align-items:center; font-size:11px; color:var(--ink-500); gap:6px; margin-left:14px; }
    .rfn-search .kbd { margin-left:auto; font-family:var(--font-mono); font-size:9.5px; background:var(--surface); border:1px solid var(--border); border-radius:3px; padding:0 4px; height:14px; display:inline-flex; align-items:center; }
    .rfn-spacer { flex:1; }
    .rfn-btn { height:24px; padding:0 10px; border-radius:var(--r-sm); background:var(--accent); color:#fff; font-size:11.5px; font-weight:500; display:inline-flex; align-items:center; gap:5px; border:none; cursor:pointer; }
    .rfn-btn-ghost { height:24px; padding:0 10px; border-radius:var(--r-sm); background:var(--surface); border:1px solid var(--border); color:var(--ink-700); font-size:11.5px; font-weight:500; display:inline-flex; align-items:center; gap:5px; cursor:pointer; }
    .rfn-ibtn { width:24px; height:24px; border-radius:var(--r-sm); border:1px solid var(--border); background:var(--surface); display:inline-flex; align-items:center; justify-content:center; color:var(--ink-600); cursor:pointer; }
    .rfn-av { width:24px; height:24px; border-radius:var(--r-pill); background:oklch(0.55 0.16 35); color:#fff; font-size:10.5px; font-weight:600; display:inline-flex; align-items:center; justify-content:center; }

    /* Main page area */
    .rfn-main { flex:1; min-width:0; display:flex; flex-direction:column; overflow:hidden; }
    .rfn-page { flex:1; overflow:auto; padding:18px 22px 22px; display:flex; flex-direction:column; gap:14px; }

    /* Page header pattern */
    .rfn-hdr { display:flex; align-items:flex-end; justify-content:space-between; gap:14px; padding-bottom:12px; border-bottom:1px solid var(--border); }
    .rfn-hdr .ey { font-size:10.5px; font-weight:500; letter-spacing:.08em; text-transform:uppercase; color:var(--ink-500); margin-bottom:3px; }
    .rfn-hdr h1 { font-family:var(--font-serif); font-style:italic; font-weight:400; font-size:26px; line-height:1; margin:0; letter-spacing:-.3px; }
    .rfn-hdr h1 .ct { font-family:var(--font-sans); font-style:normal; font-weight:500; font-size:14px; color:var(--ink-500); margin-left:7px; font-variant-numeric:tabular-nums; }
    .rfn-hdr .sub { font-size:11.5px; color:var(--ink-600); margin-top:5px; }
    .rfn-hdr .acts { display:flex; gap:6px; align-items:center; }

    /* Cards */
    .rfn-card { background:var(--surface); border:1px solid var(--border); border-radius:var(--r-card); padding:14px 16px; }
    .rfn-card .h { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
    .rfn-card h3 { font-size:12px; font-weight:600; letter-spacing:-.005em; margin:0; }
    .rfn-card .meta { font-family:var(--font-mono); font-size:10px; color:var(--ink-500); }

    /* KPI */
    .rfn-kpi { background:var(--surface); border:1px solid var(--border); border-radius:var(--r-card); padding:12px 14px; display:flex; flex-direction:column; gap:3px; }
    .rfn-kpi .lab { font-size:9.5px; letter-spacing:.06em; text-transform:uppercase; font-weight:500; color:var(--ink-500); display:flex; justify-content:space-between; align-items:center; }
    .rfn-kpi .lab .dot { width:6px; height:6px; border-radius:var(--r-pill); }
    .rfn-kpi .v { font-family:var(--font-serif); font-size:26px; line-height:1; font-feature-settings:"tnum"; }
    .rfn-kpi .d { font-size:10.5px; color:var(--success); font-variant-numeric:tabular-nums; }
    .rfn-kpi .d.dn { color:var(--danger); }

    /* Segmented / views */
    .rfn-seg { display:inline-flex; padding:2px; background:var(--surface-2); border:1px solid var(--border); border-radius:var(--r-sm); }
    .rfn-seg span { padding:3px 9px; font-size:11px; font-weight:500; color:var(--ink-600); border-radius:4px; cursor:pointer; display:inline-flex; align-items:center; gap:4px; }
    .rfn-seg span.on { background:var(--surface); color:var(--ink-900); box-shadow:0 1px 2px rgba(0,0,0,.06); }

    /* Status pill */
    .rfn-pill { height:20px; padding:0 8px; border-radius:var(--r-pill); font-size:10.5px; font-weight:500; display:inline-flex; align-items:center; gap:5px; }
    .rfn-pill .d { width:5px; height:5px; border-radius:var(--r-pill); }

    /* Chips / filter row */
    .rfn-chip { height:24px; padding:0 9px; border-radius:var(--r-sm); background:var(--surface); border:1px solid var(--border); font-size:11px; color:var(--ink-700); display:inline-flex; align-items:center; gap:5px; cursor:pointer; }
    .rfn-chip.on { background:var(--accent-soft); border-color:var(--accent); color:var(--accent); font-weight:500; }
    .rfn-chip.dash { border-style:dashed; color:var(--ink-600); }

    /* Stars */
    .rfn-stars { color:var(--warn); font-size:10px; letter-spacing:1.4px; }
    .rfn-stars .o { color:var(--ink-300); }

    /* Avatar */
    .rfn-avatar { display:inline-flex; align-items:center; justify-content:center; background:var(--ink-200); color:var(--ink-700); font-weight:600; flex:0 0 auto; }
    .rfn-avatar.round { border-radius:var(--r-pill); }
    .rfn-avatar.square { border-radius:var(--r-md); }

    /* Empty state */
    .rfn-empty { padding:32px; text-align:center; color:var(--ink-500); }
    .rfn-empty .title { font-family:var(--font-serif); font-style:italic; font-size:18px; color:var(--ink-700); margin-bottom:6px; }
    .rfn-empty .sub { font-size:11.5px; max-width:300px; margin:0 auto; line-height:1.45; }
  `;
  return <style>{css}</style>;
}

/* Shared composed primitives (light) ───────────────────────── */

function Side({ active }) {
  const items = [
    { k:'dashboard',    lab:'Dashboard',    group:'navigate' },
    { k:'focus',        lab:'Focus',        group:'navigate' },
    { k:'calendrier',   lab:'Calendrier',   group:'navigate' },
    { k:'stats',        lab:'Stats',        group:'navigate' },
    { k:'prospects',    lab:'Prospects',    group:'records', ct:'1 306' },
    { k:'entreprises',  lab:'Entreprises',  group:'records', ct:'123' },
    { k:'candidats',    lab:'Candidats',    group:'records', ct:'76' },
    { k:'push',         lab:'Push',         group:'outils' },
    { k:'actus',        lab:'Actus',        group:'outils' },
    { k:'carte',        lab:'Carte',        group:'outils' },
    { k:'transcription',lab:'Transcription',group:'outils' },
    { k:'besoins',      lab:'Besoins',      group:'outils' },
    { k:'collab',       lab:'Collaboration',group:'outils' },
    { k:'doublons',     lab:'Doublons',     group:'outils' },
  ];
  const groups = [
    { g:'navigate', t:'Navigate' },
    { g:'records', t:'Records' },
    { g:'outils', t:'Outils' },
  ];
  return (
    <aside className="rfn-side">
      <div className="brand"><span className="mk">P</span><span className="nm">ProspUp</span></div>
      {groups.map(g => (
        <React.Fragment key={g.g}>
          <h6>{g.t}</h6>
          <div className="nav">
            {items.filter(i => i.group === g.g).map(i => (
              <a key={i.k} className={i.k === active ? 'on' : ''}>
                <span className="ic"/>{i.lab}{i.ct && <span className="ct">{i.ct}</span>}
              </a>
            ))}
          </div>
        </React.Fragment>
      ))}
      <div className="foot"><span>⚙</span><span>☼</span><span style={{flex:1}}/><span>v32.25</span></div>
    </aside>
  );
}

function Top({ crumb, ctx }) {
  return (
    <div className="rfn-top">
      <span className="rfn-crumb"><b>ProspUp</b>{crumb && crumb.map((c, i) => (
        <React.Fragment key={i}><span className="sep">›</span>{c.last ? <b>{c.t}</b> : c.t}</React.Fragment>
      ))}</span>
      <div className="rfn-search">⌕ Rechercher ou sauter vers…<span className="kbd">⌘K</span></div>
      <div className="rfn-spacer"/>
      {ctx}
      <button className="rfn-ibtn">↻</button>
      <button className="rfn-btn">＋ Créer</button>
      <span className="rfn-av">A</span>
    </div>
  );
}

function PageHdr({ eyebrow, title, count, sub, actions }) {
  return (
    <div className="rfn-hdr">
      <div style={{minWidth:0}}>
        {eyebrow && <div className="ey">{eyebrow}</div>}
        <h1>{title}{count && <span className="ct">{count}</span>}</h1>
        {sub && <div className="sub">{sub}</div>}
      </div>
      {actions && <div className="acts">{actions}</div>}
    </div>
  );
}

function Shell({ active, crumb, ctx, children }) {
  return (
    <div className="rfn-root" style={{width:'100%', height:'100%'}}>
      <div className="rfn-shell">
        <Side active={active}/>
        <div className="rfn-main">
          <Top crumb={crumb} ctx={ctx}/>
          {children}
        </div>
      </div>
    </div>
  );
}

function StatusPill({ tone, label, soft = true }) {
  const tones = {
    idle:      ['var(--st-idle)',      'Pas d\'actions'],
    prosp:     ['var(--st-prosp)',     'Prospecté'],
    called:    ['var(--st-called)',    'Appelé'],
    voicemail: ['var(--st-voicemail)', 'Messagerie'],
    callback:  ['var(--st-callback)',  'À rappeler'],
    rdv:       ['var(--st-rdv)',       'RDV pris'],
    cold:      ['var(--st-cold)',      'Boîte vocale'],
    success:   ['var(--success)',      'OK'],
    warn:      ['var(--warn)',         'Attention'],
    danger:    ['var(--danger)',       'En retard'],
    info:      ['var(--info)',         'Info'],
  };
  const [c, defLab] = tones[tone] || ['var(--ink-500)', label];
  const bg = soft ? `color-mix(in oklch, ${c} 12%, transparent)` : c;
  const fg = soft ? c : '#fff';
  return <span className="rfn-pill" style={{background:bg, color:fg}}><span className="d" style={{background:c}}/>{label || defLab}</span>;
}

function Stars({ n = 3, max = 5 }) {
  return (
    <span className="rfn-stars">
      {Array.from({length:max}).map((_,i)=>(<span key={i} className={i<n?'':'o'}>★</span>))}
    </span>
  );
}

function KPI({ label, value, delta, deltaDir = 'up', dot }) {
  return (
    <div className="rfn-kpi">
      <div className="lab">{label}{dot && <span className="dot" style={{background:dot}}/>}</div>
      <div className="v">{value}</div>
      {delta && <div className={'d ' + (deltaDir === 'dn' ? 'dn' : '')}>{deltaDir === 'up' ? '↑' : '↓'} {delta}</div>}
    </div>
  );
}

function Avatar({ initials, color, size = 24, square = false }) {
  return (
    <span className={'rfn-avatar ' + (square ? 'square' : 'round')} style={{ width:size, height:size, fontSize:Math.max(9, size * 0.4), background:color || 'var(--ink-200)', color: color ? '#fff' : 'var(--ink-700)' }}>
      {initials}
    </span>
  );
}

Object.assign(window, { RefonteStyles, Side, Top, PageHdr, Shell, StatusPill, Stars, KPI, Avatar });
