# Handoff — Refonte du Mode Prosp (direction "Hybride")

## Overview

Refonte visuelle de l'écran **Mode Prosp** de ProspUp (fiche prospect en mode appel/qualification). La structure et les fonctionnalités existantes sont **conservées** — c'est un refresh visuel + une réorganisation des actions, pas une refonte produit.

## About the Design Files

Les fichiers de ce bundle sont des **références de design en HTML/React** : un prototype illustrant l'apparence et le comportement attendus, **pas du code de production à copier tel quel**. La tâche est de **recréer ce design dans la stack existante de ProspUp** en réutilisant les patterns, composants et conventions du projet (couleurs réelles du brand, composants partagés, etc.).

## Fidelity

**Hi-fi.** Les couleurs, typographies, tailles, paddings et espacements du fichier `hybrid.jsx` sont la cible — à respecter précisément. Les couleurs neutres (papier chaud `#F6F4EF`, ink `#15171A`, etc.) peuvent être adaptées aux tokens existants si ProspUp en a déjà ; le bleu d'accent `#1E40AF` doit être remplacé par le **bleu de la marque ProspUp** (à confirmer avec l'équipe).

## Pourquoi ce refresh

Pain points identifiés sur la version actuelle (capture jointe : `reference-current-state.png`) :
1. **Manque de feedback** — statut, priorité et pertinence pas assez visibles dans la fiche.
2. **Identité visuelle trop générique / fade** — design fonctionnel mais sans personnalité.
3. **Actions dispersées** — pas de hiérarchie claire entre actions principales et secondaires.

Direction retenue : **"Hybride"** — fond clair façon papier, densité et command bar empruntées à un Linear/Superhuman, raffinement typo et hiérarchie d'un journal éditorial.

---

## Layout général

Page entière : `1400 × 880` (cible desktop, à rendre responsive selon les breakpoints existants).

```
┌─────────────────────────────────────────────────────────────────┐
│ TOPBAR (h: 48)   ← logo · titre · paginateur · ⌘K · Fermer     │
├──────┬─────────────────────────────────────────┬────────────────┤
│      │  [Onglet "Fiche · #19"]                 │                │
│ RAIL │ ┌─────────────────────────────────────┐ │   TIMELINE     │
│ (76) │ │ HEADER (avatar · nom · entreprise │ │   (320)        │
│      │ │ · 4 boutons d'action)             │ │                │
│  C   │ │─────────────────────────────────── │ │  Filtres       │
│  M   │ │ Statut · Pertinence · Priorité    │ │  Note rapide   │
│  L   │ ├─────────────────────────────────────┤ │                │
│  I   │ │ FORMULAIRE (statut, entreprise,   │ │  Timeline      │
│  ─   │ │ fonction, tel, email, LinkedIn)   │ │  éditoriale    │
│  N   │ │ ─── divider ───                   │ │  (date Fraunces│
│  S   │ │ Next action · Relance · RDV · ··· │ │  + accent)     │
│      │ │ ─── divider ───                   │ │                │
│  ✓   │ │ Notes (textarea)                  │ │                │
│      │ └─────────────────────────────────────┘ │                │
├──────┴─────────────────────────────────────────┴────────────────┤
│ COMMAND BAR (h: 40)   ⌘K + raccourcis                          │
└─────────────────────────────────────────────────────────────────┘
```

Trois zones :
- **Action rail** (gauche, 76px) — actions verbe-driven avec raccourci clavier visible.
- **Card central** — fiche prospect avec onglet "dossier", header riche, formulaire en grille, divider entre infos contact et infos commerciales.
- **Timeline** (droite, 320px) — saisie rapide en haut, fil d'activité éditorial dessous (date en serif dans la marge, événement en accent coloré).

---

## Design Tokens

### Couleurs (du fichier `hybrid.jsx`, objet `c`)
| Token | Hex | Usage |
|---|---|---|
| `bg` | `#F6F4EF` | Fond global, papier chaud |
| `surface` | `#FFFFFF` | Cards, inputs |
| `surfaceAlt` | `#FAF8F3` | Note input, kbd background |
| `rail` | `#FBFAF6` | Action rail background |
| `border` | `#E5E1D6` | Bordures standards |
| `borderStrong` | `#D4CFC0` | Étoiles vides, bordures appuyées |
| `ink` | `#15171A` | Texte principal, avatar, bouton primaire |
| `inkSoft` | `#3D424A` | Texte secondaire |
| `inkMuted` | `#73767D` | Labels, métadonnées |
| `inkSubtle` | `#A0A29E` | Placeholders, mentions discrètes |
| `accent` | `#1E40AF` | **À remplacer par le bleu ProspUp.** Liens, hints |
| `accentSoft` | `#E6ECFB` | Backgrounds d'accent légers |
| `star` | `#B5803A` | Étoiles de pertinence (or chaud) |
| `msg` | `#5B3FBF` | Statut "Messagerie" (violet) |
| `msgSoft` | `#EFEAFB` | Background messagerie léger |
| `success` | `#0F7B5C` | Téléphone, appel sortant |
| `successSoft` | `#E3F2EC` | — |

### Typographie
- **Sans (UI, formulaires, body)** : `Inter`, fallback `-apple-system, sans-serif`. Poids 400/500/600/700.
- **Serif (titres, dates, P2)** : `Fraunces`, fallback `"Times New Roman", serif`. Poids 400/500, italique pour les noms de famille et mentions douces.
- **Mono (raccourcis, kbd)** : `JetBrains Mono`, monospace.

Échelle :
| Usage | Taille | Poids | Detail |
|---|---|---|---|
| Nom du prospect (h1) | 30px | 500 | Fraunces, letter-spacing -0.02em, prénom roman + nom italique |
| Métier (eyebrow header) | 10px | 600 | Inter uppercase, letter-spacing 0.14em |
| Labels formulaire | 10px | 600 | Inter uppercase, letter-spacing 0.12em, `inkMuted` |
| Champs (input/select) | 13px | 400 | Inter, hauteur 36px, padding 8/12, radius 6 |
| Boutons header | 12px | 500 | Inter |
| Body timeline | 12px | 400 | Inter, line-height 1.45 |
| Timeline date | 13px | 500 | Fraunces |
| Statut / kind tag timeline | 10px | 600 | Inter uppercase, letter-spacing 0.08em |
| Kbd / raccourcis | 9–10px | 400 | JetBrains Mono |
| Priorité "P2" | 16px | 500 | Fraunces, tabular-nums |

### Espacement & radius
- Radius cards : `8px` (avec onglet : `0 8 8 8`)
- Radius inputs / boutons : `6px`
- Radius kbd : `3–4px`
- Padding card header : `24 28 20`
- Padding card form : `22 28`
- Padding rail : `14 0`
- Bordures : `1px solid border` sauf séparateurs internes (`1px dotted border` dans la timeline)

### Iconographie
Set d'icônes SVG line, **stroke 1.5px**, viewBox 24×24, `stroke-linecap: round`, `stroke-linejoin: round`. **Pas d'emoji.** Voir le composant `Icon` dans `hybrid.jsx` pour les paths exacts.

Noms : `phone`, `mail`, `linkedin`, `in` (logo solid), `sparkle` (IA), `note`, `flag`, `check`, `close`, `chevL`, `chevR`, `arrow`, `cmd`, `refresh`, `calendar`, `chat`.

À adapter au set d'icônes existant de ProspUp si déjà en place — sinon, copier ces paths.

---

## Composants détaillés

### 1. Topbar (h: 48px, fond surface, border-bottom)
- Logo à gauche : 24×24 carré `ink` avec "P" en Fraunces blanc.
- Titre "Mode Prosp" en Fraunces 16px + sous-label uppercase 9px (`Fiche 19/45`).
- Centre vide (peut accueillir un breadcrumb).
- Droite : paginateur (chev gauche/droite + "19 / 45" tabular-nums), bouton ⌘K (kbd + label "Commande…", `inkMuted`), bouton "Fermer" (icon close + label).

### 2. Action rail (gauche, 76px)
8 boutons verticaux (`RailBtn`), chacun :
- Icone dans un carré 30×30 `surface` border `border` radius 7
- Label 10px 500 `inkMuted` letter-spacing 0.04em
- Kbd (raccourci) 9px monospace dans un kbd `surfaceAlt`
- Icone tinté en `success` pour Appeler, en `accent` pour IA et Sauver.

Actions, dans l'ordre : **Appeler (C) · Email (M) · LinkedIn (L) · IA (I)** — séparateur — **Note (N) · Statut (S)** — flex spacer — **Sauver (↵)**.

### 3. Card prospect

**Onglet "Fiche · #19"** : petit onglet papier au-dessus de la card, padding 5/14, fond `surface`, border sauf bottom, radius `6 6 0 0`, label 10px uppercase letter-spacing 0.12em.

**Header** :
- Avatar 60×60 carré radius 8, fond `ink`, initiales en Fraunces 22px 500.
- Eyebrow métier (10px uppercase) + nom (Fraunces 30px, prénom roman + nom italique) + entreprise (13px, nom italique).
- 4 boutons d'action à droite : Appeler / Email / LinkedIn (outline `border`, fond `surface`, icone 13px tinté + label 12px 500 + kbd dans un kbd `surfaceAlt`) ; **Demander à l'IA** en bouton primaire `ink` / texte `surface`.

**Status row** (sous le header, dans le même padding) :
- Trois groupes séparés par séparateurs verticaux 1px×22 `border`.
- Statut : badge `msg` violet plein, surface texte, dot 5px, padding 4/10, radius 4.
- Pertinence : 5 étoiles 13×13, remplies en `star`, vides en `borderStrong`.
- Priorité : "P2" en Fraunces 16px + label "normal" en italique 11px `inkMuted`.
- À droite : "Dernier contact 30 avr · 15:32".

**Form grid** :
- 2 colonnes 1fr 1fr, gap 18×28, champs : Statut, Entreprise, Fonction, Téléphone, Email, LinkedIn.
- Champs Tel/Email/LinkedIn ont un `hint` cliquable en italique `accent` 11px sous le champ (ex. "↗ Composer +33 4 72 00 18 70").
- Divider `1px solid border`, marge `6 0 18`.
- 4 colonnes 1fr×4, gap 18×20 : Next action · Relance (date) · Date RDV (datetime) · Dernier contact.
- Divider.
- 2 colonnes 1fr×2 : Notes (textarea 3 lignes) · Tags (input avec chips simulés).

### 4. Timeline (droite, 320px, border-left)

**Filtres** (bandeau h: 40 environ) : pills 11px `Tous` (active = `ink` plein) · `Appels` · `Mails` · `Statuts` · `Notes`.

**Note rapide** (encart `surfaceAlt` border radius 7 padding 10) :
- Input "Note rapide…" sans border ni background.
- 4 mini-boutons icone 24×24 (phone/mail/calendar/chat) à gauche, bouton "Ajouter" `ink` plein à droite.

**Fil éditorial** (padding 16/22, scroll auto) :
Chaque item est une grille `52px 1fr` avec :
- **Marge gauche** : date en Fraunces 13px 500 (ex. "30 avr") + heure dessous en 10px `inkSubtle` tabular-nums.
- **Contenu** : `border-left 2px solid <accent>` du type d'événement, padding-left 12px. Eyebrow en uppercase 10px 600 letter-spacing 0.08em coloré selon l'événement (success/msg/accent/star/inkMuted) + body 12px `inkSoft`. Durée optionnelle en italique `inkSubtle`.
- Séparateur entre items : `1px dotted border`, padding-bottom + margin-bottom 14.

Événements de référence : Appel sortant (success) · Statut modifié (msg) · Note d'appel (accent) · Pertinence (star) · Création (inkMuted).

### 5. Command bar (bas, h: 40px, fond surface, border-top)
- À gauche : `⌘ K` en deux kbd + texte "tape pour rechercher, statuer, naviguer…" en `inkSubtle`.
- À droite (flex spacer) : raccourcis labellisés `←/→ Naviguer` · `1—7 Statut direct` · `N Note` · `↵ Sauvegarder` · `Esc Fermer`. Chaque kbd dans un kbd `surfaceAlt` border `border` radius 4.

---

## Interactions & Behavior

- **Boutons rail** : actions instantanées, raccourcis clavier `C / M / L / I / N / S / Enter`.
- **Boutons header** : redondants avec le rail (volontairement — utilisateurs power vs nouveaux). Mêmes raccourcis.
- **Statut/Pertinence/Priorité** dans le header : **cliquables** pour ouvrir un menu. La même donnée existe aussi dans le formulaire (acceptable car la cible utilise majoritairement les boutons rail/header pour aller vite, et le formulaire pour saisir en détail).
- **Hints "↗ Composer / Envoyer / Voir le profil"** sous Tel/Email/LinkedIn : déclenchent l'action correspondante (équivalent aux boutons header, mais accessibles depuis le formulaire).
- **Filtres timeline** : filtrent le fil par type. État actif = bouton `ink` plein.
- **Note rapide** : Enter ou bouton "Ajouter" pour insérer un événement timeline de type Note. Les 4 icones préfixent le type.
- **⌘K** : ouvre une command bar (à brancher sur la cmd bar existante de ProspUp s'il y en a une).
- **Pagination** : ←/→ navigue dans la liste de prospects, met à jour le compteur "19 / 45".

## State Management

Aucun nouveau state global. La fiche consomme les mêmes données que le mode actuel :
- Prospect (id, nom, prénom, fonction, entreprise, tel, email, LinkedIn, …)
- Statut (énum existant)
- Pertinence (1–5)
- Priorité (P1/P2/P3 + label)
- Timeline d'événements (existante)
- Index dans la liste paginée

Aucun champ supplémentaire à ajouter en BDD.

## Responsive

Cible primaire desktop (1400px+). Pour < 1280 :
- Réduire le rail à 64px (icones seules, labels+kbd en tooltip).
- Réduire la timeline à 280px.
- À < 1024px : passer le formulaire en 1 colonne, masquer la timeline derrière un bouton "Activité" qui l'ouvre en panneau coulissant.

## Assets

- **Capture de l'état actuel** : `reference-current-state.png` — pour comparaison avant/après.
- **Polices** : Inter, Fraunces, JetBrains Mono — déjà disponibles via Google Fonts. Vérifier si ProspUp les a déjà chargées sinon les ajouter au `<head>` global.
- **Icones** : SVG inline, voir composant `Icon` dans `hybrid.jsx`. À aligner sur le set existant.

## Files

- `Mode Prosp - Hybride.html` — page d'aperçu standalone du design.
- `hybrid.jsx` — code React du prototype, source de vérité pour valeurs exactes (copier les hex, paddings, paths SVG).
- `reference-current-state.png` — capture du Mode Prosp avant refonte.

## Notes pour l'implémentation

1. Le bleu `#1E40AF` est un **placeholder** ; remplacer par le bleu officiel ProspUp.
2. Si ProspUp utilise déjà une grille de tokens (Tailwind config, design tokens), mapper les valeurs ci-dessus dessus plutôt que de hardcoder.
3. Le composant `Icon` du prototype est **autonome** ; à remplacer par le set d'icônes existant (lucide-react, heroicons, …) en gardant la stroke 1.5 et la grille 24.
4. Les boutons rail + boutons header dupliquent volontairement les actions principales. **Ne pas en supprimer un** sans valider avec design — la redondance est un choix UX (rail = power user, header = découvrabilité).
5. La timeline doit être virtualisée si la liste d'événements peut être longue (> 50).
