// Direction 4 — HYBRID (Cockpit ⨯ Editorial, en clair)
// Densité + barre d'action latérale + command bar + timeline riche (du Cockpit)
// Raffinement typo, hiérarchie forte, statuts traités comme étiquettes (de l'Editorial)
// Boutons d'action retravaillés : plus fins, plus typés, plus chics.

const HybridProspMode = () => {
  const c = {
    bg: '#F6F4EF',           // fond chaud, papier
    surface: '#FFFFFF',
    surfaceAlt: '#FAF8F3',
    rail: '#FBFAF6',
    border: '#E5E1D6',
    borderStrong: '#D4CFC0',
    ink: '#15171A',
    inkSoft: '#3D424A',
    inkMuted: '#73767D',
    inkSubtle: '#A0A29E',
    accent: '#1E40AF',
    accentSoft: '#E6ECFB',
    star: '#B5803A',
    msg: '#5B3FBF',
    msgSoft: '#EFEAFB',
    success: '#0F7B5C',
    successSoft: '#E3F2EC',
  };

  const fieldStyle = {
    width: '100%', background: c.surface,
    border: `1px solid ${c.border}`, borderRadius: 6,
    padding: '8px 12px', fontSize: 13, color: c.ink,
    fontFamily: 'inherit', height: 36, boxSizing: 'border-box', outline: 'none',
  };

  const labelStyle = {
    fontSize: 10, fontWeight: 600, color: c.inkMuted,
    letterSpacing: '0.12em', textTransform: 'uppercase',
    marginBottom: 6, display: 'block',
  };

  const Field = ({ label, children, hint }) => (
    <div>
      <label style={labelStyle}>{label}</label>
      {children}
      {hint ? <div style={{ fontSize: 11, color: c.accent, marginTop: 4, fontStyle: 'italic', cursor: 'pointer' }}>{hint}</div> : null}
    </div>
  );

  // Clean SVG icon set — line, 1.5px stroke, harmonised
  const Icon = ({ name, size = 16, color = 'currentColor', strokeWidth = 1.5 }) => {
    const props = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
      stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round' };
    switch (name) {
      case 'phone':   return <svg {...props}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>;
      case 'mail':    return <svg {...props}><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg>;
      case 'linkedin':return <svg {...props}><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>;
      case 'sparkle': return <svg {...props}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>;
      case 'note':    return <svg {...props}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h4"/></svg>;
      case 'flag':    return <svg {...props}><path d="M4 22V4a1 1 0 0 1 1-1h11l-2 4 2 4H5"/></svg>;
      case 'check':   return <svg {...props}><path d="m5 12 5 5L20 7"/></svg>;
      case 'close':   return <svg {...props}><path d="M18 6 6 18M6 6l12 12"/></svg>;
      case 'chevL':   return <svg {...props}><path d="m15 18-6-6 6-6"/></svg>;
      case 'chevR':   return <svg {...props}><path d="m9 18 6-6-6-6"/></svg>;
      case 'arrow':   return <svg {...props}><path d="M7 17 17 7M9 7h8v8"/></svg>;
      case 'cmd':     return <svg {...props}><path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>;
      case 'in':      return <svg viewBox="0 0 24 24" width={size} height={size} fill={color}><path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM5 8H0v15h5V8zm7.98 0H8.02v15h4.96v-7.88c0-4.62 6-5 6 0V23H24v-9.62c0-7.71-8.79-7.43-11.02-3.64V8z"/></svg>;
      case 'refresh': return <svg {...props}><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>;
      case 'calendar':return <svg {...props}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>;
      case 'chat':   return <svg {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
      default: return null;
    }
  };

  // Refined side button — discret, propre
  const RailBtn = ({ icon, label, hot, accent }) => (
    <button style={{
      display:'flex', flexDirection:'column', alignItems:'center', gap: 6,
      width: 60, padding: '12px 4px',
      background: 'transparent', border: '1px solid transparent',
      borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit',
      color: c.ink,
    }}>
      <span style={{
        width: 30, height: 30, borderRadius: 7,
        display:'flex', alignItems:'center', justifyContent:'center',
        background: c.surface, border: `1px solid ${c.border}`,
        fontSize: 13, color: accent || c.inkSoft,
      }}>{icon}</span>
      <span style={{ fontSize: 10, fontWeight: 500, color: c.inkMuted, letterSpacing: '0.04em' }}>{label}</span>
      <kbd style={{
        fontFamily:'"JetBrains Mono", monospace', fontSize: 9,
        padding:'1px 5px', borderRadius: 3,
        background: c.surfaceAlt, border: `1px solid ${c.border}`,
        color: c.inkSubtle, lineHeight: 1.2,
      }}>{hot}</kbd>
    </button>
  );

  const Star = ({ filled }) => (
    <svg width="13" height="13" viewBox="0 0 24 24" fill={filled ? c.star : 'none'} stroke={filled ? c.star : c.borderStrong} strokeWidth="1.5">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
    </svg>
  );

  return (
    <div style={{
      width: 1400, height: 880, background: c.bg,
      fontFamily: '"Inter", -apple-system, sans-serif',
      color: c.ink, display:'flex', flexDirection:'column',
    }}>
      {/* TOP BAR */}
      <div style={{
        height: 52, borderBottom: `1px solid ${c.border}`,
        background: c.surface, padding: '0 24px',
        display:'flex', alignItems:'center', justifyContent:'space-between',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
          <div style={{
            width: 26, height: 26, borderRadius: 5, background: c.ink,
            color: c.surface, display:'flex', alignItems:'center', justifyContent:'center',
            fontWeight: 700, fontSize: 13, fontFamily:'"Fraunces",serif',
          }}>P</div>
          <span style={{ fontSize: 12, color: c.inkMuted, letterSpacing: '0.04em' }}>PROSP'UP</span>
          <span style={{ color: c.inkSubtle }}>›</span>
          <span style={{ fontSize: 12, fontWeight: 600, letterSpacing:'0.06em', textTransform:'uppercase' }}>Mode Prosp</span>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap: 14 }}>
          <button style={{
            width: 26, height: 26, borderRadius: 5,
            border: `1px solid ${c.border}`, background: c.surface, cursor:'pointer',
            color: c.inkMuted, fontSize: 14,
          }}>‹</button>
          <div style={{ display:'flex', alignItems:'baseline', gap: 8 }}>
            <span style={{
              fontFamily:'"Fraunces","Times New Roman",serif',
              fontSize: 18, fontWeight: 500, color: c.ink, fontVariantNumeric: 'tabular-nums',
            }}>19</span>
            <span style={{ fontSize: 12, color: c.inkSubtle }}>/ 1306</span>
          </div>
          <div style={{ width: 160, height: 3, background: c.border, borderRadius: 2, overflow:'hidden' }}>
            <div style={{ width: '1.4%', height:'100%', background: c.ink }}/>
          </div>
          <button style={{
            width: 26, height: 26, borderRadius: 5,
            border: `1px solid ${c.border}`, background: c.surface, cursor:'pointer',
            color: c.inkMuted, fontSize: 14,
          }}>›</button>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
          <button style={{
            display:'inline-flex', alignItems:'center', gap: 8,
            padding:'6px 12px', fontSize: 12,
            background: c.surface, border: `1px solid ${c.border}`,
            borderRadius: 6, cursor:'pointer', color: c.inkMuted, fontFamily:'inherit',
          }}>
            <kbd style={{ fontFamily:'monospace', fontSize: 10 }}>⌘K</kbd>
            <span style={{ color: c.inkSubtle }}>Commande…</span>
          </button>
          <button style={{
            padding:'6px 10px 6px 8px', fontSize: 12,
            background: c.surface, border: `1px solid ${c.border}`,
            borderRadius: 6, cursor:'pointer', color: c.ink, fontFamily:'inherit',
            display:'inline-flex', alignItems:'center', gap: 6,
          }}><Icon name="close" size={12}/> Fermer</button>
        </div>
      </div>

      {/* MAIN */}
      <div style={{ flex: 1, display:'flex', overflow:'hidden' }}>
        {/* LEFT ACTION RAIL */}
        <div style={{
          width: 76, borderRight: `1px solid ${c.border}`,
          background: c.rail, display:'flex', flexDirection:'column',
          alignItems:'center', padding: '14px 0', gap: 2,
        }}>
          <RailBtn icon={<Icon name="phone" size={15}/>} label="Appeler" hot="C" accent={c.success}/>
          <RailBtn icon={<Icon name="mail" size={15}/>} label="Email" hot="M"/>
          <RailBtn icon={<Icon name="in" size={14}/>} label="LinkedIn" hot="L"/>
          <RailBtn icon={<Icon name="sparkle" size={15}/>} label="IA" hot="I" accent={c.accent}/>
          <div style={{ width: 32, height: 1, background: c.border, margin: '8px 0' }}/>
          <RailBtn icon={<Icon name="note" size={15}/>} label="Note" hot="N"/>
          <RailBtn icon={<Icon name="refresh" size={15}/>} label="Statut" hot="S"/>
          <div style={{ flex: 1 }}/>
          <RailBtn icon={<Icon name="check" size={15}/>} label="Sauver" hot="↵" accent={c.accent}/>
        </div>

        {/* CARD */}
        <div style={{ flex: 1, padding: '28px 20px', overflow:'auto' }}>
          {/* Folder tab */}
          <div style={{ display:'flex', gap: 6, marginBottom: -1, paddingLeft: 6 }}>
            <div style={{
              padding: '5px 14px', background: c.surface,
              border: `1px solid ${c.border}`, borderBottom: 'none',
              borderRadius: '6px 6px 0 0',
              fontSize: 10, fontWeight: 600, letterSpacing: '0.12em', textTransform:'uppercase',
              color: c.inkMuted,
            }}>Fiche · #19</div>
          </div>

          <div style={{
            background: c.surface, border: `1px solid ${c.border}`,
            borderRadius: '0 8px 8px 8px', overflow:'hidden',
          }}>
            {/* HEADER */}
            <div style={{ padding: '24px 28px 20px', borderBottom: `1px solid ${c.border}` }}>
              <div style={{ display:'flex', gap: 18, alignItems:'flex-start' }}>
                <div style={{
                  width: 60, height: 60, borderRadius: 8,
                  background: c.ink, color: c.surface,
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontFamily:'"Fraunces","Times New Roman",serif',
                  fontWeight: 500, fontSize: 22, letterSpacing:'0.02em', flexShrink: 0,
                }}>AH</div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 10, fontWeight: 600, letterSpacing:'0.14em', color: c.inkMuted, textTransform:'uppercase', marginBottom: 4 }}>
                    Information Technology Project Manager
                  </div>
                  <h1 style={{
                    fontFamily:'"Fraunces","Times New Roman",serif',
                    fontSize: 30, fontWeight: 500, margin: 0,
                    lineHeight: 1.1, letterSpacing:'-0.02em', color: c.ink,
                  }}>
                    Hocine <span style={{ fontStyle:'italic', color: c.inkSoft }}>Aggoun</span>
                  </h1>
                  <div style={{ marginTop: 4, fontSize: 13, color: c.inkSoft }}>
                    CNR — <span style={{ fontStyle:'italic' }}>Compagnie Nationale du Rhône</span>
                  </div>
                </div>

                {/* Status group, refined buttons */}
                <div style={{ display:'flex', gap: 6, alignItems:'flex-start' }}>
                  <button style={{
                    display:'inline-flex', alignItems:'center', gap: 7,
                    padding:'7px 12px', fontSize: 12, fontWeight: 500,
                    background: c.surface, border: `1px solid ${c.border}`,
                    borderRadius: 6, cursor: 'pointer', color: c.ink, fontFamily:'inherit',
                  }}>
                    <span style={{ display:'inline-flex', color: c.success }}><Icon name="phone" size={13}/></span>
                    Appeler
                    <kbd style={{
                      fontFamily:'monospace', fontSize: 9,
                      padding:'1px 4px', background: c.surfaceAlt, color: c.inkSubtle,
                      borderRadius: 3, border:`1px solid ${c.border}`, marginLeft: 2,
                    }}>C</kbd>
                  </button>
                  <button style={{
                    display:'inline-flex', alignItems:'center', gap: 7,
                    padding:'7px 12px', fontSize: 12, fontWeight: 500,
                    background: c.surface, border: `1px solid ${c.border}`,
                    borderRadius: 6, cursor: 'pointer', color: c.ink, fontFamily:'inherit',
                  }}>
                    <span style={{ display:'inline-flex' }}><Icon name="mail" size={13}/></span>
                    Email
                    <kbd style={{
                      fontFamily:'monospace', fontSize: 9,
                      padding:'1px 4px', background: c.surfaceAlt, color: c.inkSubtle,
                      borderRadius: 3, border:`1px solid ${c.border}`, marginLeft: 2,
                    }}>M</kbd>
                  </button>
                  <button style={{
                    display:'inline-flex', alignItems:'center', gap: 7,
                    padding:'7px 12px', fontSize: 12, fontWeight: 500,
                    background: c.surface, border: `1px solid ${c.border}`,
                    borderRadius: 6, cursor: 'pointer', color: c.ink, fontFamily:'inherit',
                  }}>
                    <span style={{ display:'inline-flex' }}><Icon name="in" size={12}/></span>
                    LinkedIn
                  </button>
                  <button style={{
                    display:'inline-flex', alignItems:'center', gap: 7,
                    padding:'7px 12px', fontSize: 12, fontWeight: 500,
                    background: c.ink, border: `1px solid ${c.ink}`,
                    borderRadius: 6, cursor: 'pointer', color: c.surface, fontFamily:'inherit',
                  }}>
                    <span style={{ display:'inline-flex' }}><Icon name="sparkle" size={12}/></span>
                    Demander à l'IA
                  </button>
                </div>
              </div>

              {/* Status row — étiquettes papier */}
              <div style={{ display:'flex', alignItems:'center', gap: 24, marginTop: 18 }}>
                <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
                  <span style={{ fontSize: 9, fontWeight: 600, letterSpacing:'0.14em', color: c.inkMuted, textTransform:'uppercase' }}>Statut</span>
                  <div style={{
                    display:'inline-flex', alignItems:'center', gap: 7,
                    padding:'4px 10px', borderRadius: 4,
                    background: c.msg, color: c.surface,
                    fontSize: 11, fontWeight: 500, letterSpacing:'0.03em',
                  }}>
                    <span style={{ width: 5, height: 5, borderRadius:'50%', background: c.surface }}/>
                    Messagerie
                  </div>
                </div>
                <div style={{ width: 1, height: 22, background: c.border }}/>
                <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
                  <span style={{ fontSize: 9, fontWeight: 600, letterSpacing:'0.14em', color: c.inkMuted, textTransform:'uppercase' }}>Pertinence</span>
                  <div style={{ display:'flex', gap: 2 }}>
                    {[1,2,3,4,5].map(i => <Star key={i} filled={i <= 3}/>)}
                  </div>
                </div>
                <div style={{ width: 1, height: 22, background: c.border }}/>
                <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
                  <span style={{ fontSize: 9, fontWeight: 600, letterSpacing:'0.14em', color: c.inkMuted, textTransform:'uppercase' }}>Priorité</span>
                  <span style={{
                    fontFamily:'"Fraunces","Times New Roman",serif',
                    fontSize: 16, fontWeight: 500, color: c.ink, fontVariantNumeric:'tabular-nums', lineHeight: 1,
                  }}>P2</span>
                  <span style={{ fontSize: 11, color: c.inkMuted, fontStyle:'italic' }}>normal</span>
                </div>
                <div style={{ flex: 1 }}/>
                <div style={{ fontSize: 11, color: c.inkSubtle }}>Dernier contact <span style={{ color: c.inkSoft, fontVariantNumeric:'tabular-nums' }}>30 avr · 15:32</span></div>
              </div>
            </div>

            {/* FORM */}
            <div style={{ padding: '22px 28px' }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'18px 28px', marginBottom: 16 }}>
                <Field label="Statut">
                  <select style={fieldStyle} defaultValue="Messagerie"><option>Messagerie</option></select>
                </Field>
                <Field label="Entreprise">
                  <select style={fieldStyle}><option>CNR (Compagnie Nationale du Rhône)</option></select>
                </Field>
                <Field label="Fonction">
                  <input style={fieldStyle} defaultValue="Information Technology Project Manager"/>
                </Field>
                <Field label="Téléphone" hint="↗ Composer +33 4 72 00 18 70">
                  <input style={fieldStyle} defaultValue="+33 4 72 00 18 70 ; +33 6 79 47 21 30"/>
                </Field>
                <Field label="Email" hint="↗ Envoyer à hocinea@cnr.tm.fr">
                  <input style={fieldStyle} defaultValue="hocinea@cnr.tm.fr"/>
                </Field>
                <Field label="LinkedIn" hint="↗ Voir le profil">
                  <input style={fieldStyle} defaultValue="linkedin.com/in/aggoun-hocine-b0447b110"/>
                </Field>
              </div>

              <div style={{ height: 1, background: c.border, margin: '6px 0 18px' }}/>

              <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:'18px 20px' }}>
                <Field label="Next action">
                  <input style={fieldStyle} placeholder="ex. Relancer mardi 14h"/>
                </Field>
                <Field label="Relance">
                  <input style={fieldStyle} type="date" defaultValue="2026-05-12"/>
                </Field>
                <Field label="Date RDV">
                  <input style={fieldStyle} type="datetime-local"/>
                </Field>
                <Field label="Dernier contact">
                  <input style={fieldStyle} type="datetime-local" defaultValue="2026-04-30T15:32"/>
                </Field>
              </div>

              <div style={{
                display:'flex', justifyContent:'space-between', alignItems:'center',
                marginTop: 22, paddingTop: 18, borderTop: `1px solid ${c.border}`,
              }}>
                <div style={{ fontSize: 11, color: c.inkSubtle, fontStyle:'italic' }}>
                  Modifié il y a <span style={{ color: c.inkMuted, fontStyle:'normal' }}>6 jours</span>
                </div>
                <div style={{ display:'flex', gap: 8 }}>
                  <button style={{
                    padding:'8px 14px', fontSize: 12, fontWeight: 500,
                    background: c.surface, border: `1px solid ${c.border}`, borderRadius: 6,
                    cursor:'pointer', color: c.inkMuted, fontFamily:'inherit',
                  }}>Annuler</button>
                  <button style={{
                    padding:'8px 18px', fontSize: 12, fontWeight: 500,
                    background: c.ink, color: c.surface, border: 'none',
                    borderRadius: 6, cursor:'pointer', fontFamily:'inherit',
                    display:'inline-flex', alignItems:'center', gap: 8,
                  }}>
                    Enregistrer
                    <kbd style={{
                      fontFamily:'monospace', fontSize: 10,
                      padding:'1px 5px', borderRadius: 3,
                      background:'rgba(255,255,255,0.18)', color: c.surface,
                    }}>↵</kbd>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT — TIMELINE */}
        <div style={{
          width: 340, borderLeft: `1px solid ${c.border}`,
          background: c.surface, display:'flex', flexDirection:'column',
        }}>
          <div style={{ padding:'18px 22px 14px', borderBottom: `1px solid ${c.border}` }}>
            <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 10, fontWeight: 600, letterSpacing:'0.14em', color: c.inkMuted, textTransform:'uppercase' }}>Journal</span>
              <span style={{ fontSize: 11, color: c.inkSubtle, fontVariantNumeric:'tabular-nums' }}>5 événements</span>
            </div>
            <h3 style={{
              fontFamily:'"Fraunces","Times New Roman",serif',
              fontSize: 20, fontWeight: 500, margin: 0, letterSpacing:'-0.01em',
            }}>Notes &amp; <span style={{ fontStyle:'italic' }}>activité</span></h3>

            <div style={{ display:'flex', gap: 4, marginTop: 12 }}>
              {['Tout','Appels','Mails','Notes'].map((t,i) => (
                <button key={t} style={{
                  fontSize: 10, padding:'4px 9px', borderRadius: 4,
                  background: i===0 ? c.ink : 'transparent',
                  border: `1px solid ${i===0 ? c.ink : c.border}`,
                  color: i===0 ? c.surface : c.inkMuted, cursor:'pointer', fontFamily:'inherit',
                  fontWeight: i===0 ? 500 : 400,
                }}>{t}</button>
              ))}
            </div>
          </div>

          {/* Note input */}
          <div style={{ padding: 14, borderBottom: `1px solid ${c.border}` }}>
            <div style={{
              background: c.surfaceAlt, border: `1px solid ${c.border}`,
              borderRadius: 7, padding: 10,
            }}>
              <input placeholder="Note rapide…" style={{
                width:'100%', border:'none', outline:'none', background:'transparent',
                color: c.ink, fontSize: 13, fontFamily:'inherit', marginBottom: 8,
              }}/>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <div style={{ display:'flex', gap: 4 }}>
                  {[
                    { i:'phone', t: c.success },
                    { i:'mail', t: c.inkSoft },
                    { i:'calendar', t: c.inkSoft },
                    { i:'chat', t: c.inkSoft },
                  ].map((b, idx) => (
                    <button key={idx} style={{
                      width: 24, height: 24,
                      display:'inline-flex', alignItems:'center', justifyContent:'center',
                      background: c.surface, border:`1px solid ${c.border}`, borderRadius: 4,
                      color: b.t, cursor:'pointer',
                    }}><Icon name={b.i} size={12} color={b.t}/></button>
                  ))}
                </div>
                <button style={{
                  padding:'4px 12px', fontSize: 11, fontWeight: 500,
                  background: c.ink, color: c.surface, border:'none',
                  borderRadius: 4, cursor:'pointer', fontFamily:'inherit',
                }}>Ajouter</button>
              </div>
            </div>
          </div>

          {/* Editorial timeline — date in margin */}
          <div style={{ flex: 1, overflow:'auto', padding: '16px 22px' }}>
            {[
              { date:'30 avr', time:'15:32', kind:'Appel sortant', body:'Statut → Messagerie', dur:'1m 24s', accent: c.success },
              { date:'30 avr', time:'15:32', kind:'Statut modifié', body:'En attente → Messagerie', accent: c.msg },
              { date:'30 mar', time:'11:14', kind:'Note d\'appel', body:'« en réunion »', accent: c.accent },
              { date:'12 mar', time:'09:00', kind:'Pertinence', body:'Définie à 3/5 étoiles', accent: c.star },
              { date:'03 mar', time:'',      kind:'Création', body:'Importé depuis CSV', accent: c.inkMuted },
            ].map((e, i, arr) => (
              <div key={i} style={{
                display:'grid', gridTemplateColumns:'52px 1fr', gap: 12,
                paddingBottom: 14, marginBottom: 14,
                borderBottom: i < arr.length - 1 ? `1px dotted ${c.border}` : 'none',
              }}>
                <div style={{
                  fontFamily:'"Fraunces","Times New Roman",serif',
                  fontSize: 13, fontWeight: 500, color: c.ink, lineHeight: 1.2,
                }}>
                  {e.date}
                  {e.time ? <div style={{ fontSize: 10, color: c.inkSubtle, fontFamily:'"Inter",sans-serif', marginTop: 2, fontVariantNumeric: 'tabular-nums' }}>{e.time}</div> : null}
                </div>
                <div style={{ borderLeft: `2px solid ${e.accent}`, paddingLeft: 12 }}>
                  <div style={{ fontSize: 10, fontWeight: 600, letterSpacing:'0.08em', textTransform:'uppercase', color: e.accent, marginBottom: 4 }}>
                    {e.kind}
                  </div>
                  <div style={{ fontSize: 12, color: c.inkSoft, lineHeight: 1.45 }}>
                    {e.body}
                    {e.dur ? <span style={{ color: c.inkSubtle, fontStyle:'italic' }}>  ·  {e.dur}</span> : null}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* COMMAND BAR */}
      <div style={{
        height: 40, borderTop: `1px solid ${c.border}`, background: c.surface,
        display:'flex', alignItems:'center', padding: '0 20px', gap: 14,
        fontSize: 11, color: c.inkMuted,
      }}>
        <span style={{ fontFamily:'"Fraunces","Times New Roman",serif', fontStyle:'italic', color: c.inkSoft, fontSize: 12 }}>
          Commande —
        </span>
        <div style={{
          display:'inline-flex', alignItems:'center', gap: 6,
          padding:'3px 10px', background: c.surfaceAlt, border:`1px solid ${c.border}`,
          borderRadius: 5,
        }}>
          <kbd style={{ fontFamily:'monospace', fontSize: 10 }}>⌘</kbd>
          <kbd style={{ fontFamily:'monospace', fontSize: 10 }}>K</kbd>
          <span style={{ color: c.inkSubtle, marginLeft: 4 }}>tape pour rechercher, statuer, naviguer…</span>
        </div>
        <div style={{ flex: 1 }}/>
        {[['←/→','Naviguer'],['1—7','Statut direct'],['N','Note'],['↵','Sauvegarder'],['Esc','Fermer']].map(([k,l]) => (
          <span key={k} style={{ display:'inline-flex', alignItems:'center', gap: 5 }}>
            <kbd style={{
              fontFamily:'"JetBrains Mono", monospace', fontSize: 10,
              padding:'2px 6px', background: c.surfaceAlt,
              border:`1px solid ${c.border}`, color: c.ink, borderRadius: 4,
            }}>{k}</kbd>
            <span style={{ fontStyle:'italic' }}>{l}</span>
          </span>
        ))}
      </div>
    </div>
  );
};

window.HybridProspMode = HybridProspMode;
